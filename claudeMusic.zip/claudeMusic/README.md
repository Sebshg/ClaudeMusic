# claudeMusic

Cliente Android de YouTube Music: abre la interfaz completa de music.youtube.com
(tu cuenta, biblioteca, playlists, radios, letras) dentro de una app, con:

- Reproducción en segundo plano (servicio en primer plano)
- Notificación con anterior / pausa / siguiente y carátula
- Controles en pantalla de bloqueo y auriculares (MediaSession)
- Botón Atrás navega dentro de la app y, al final, la manda a segundo plano
- Abre enlaces de music.youtube.com

## Compilar

1. Abre la carpeta en **Android Studio** (Koala o más reciente, JDK 17).
2. Espera la sincronización de Gradle.
3. Conecta el teléfono (depuración USB) y pulsa **Run**, o usa
   **Build > Build APK(s)** para generar el instalable.

## Notas

- Si Google bloquea el inicio de sesión dentro de la app ("navegador no seguro"),
  cambia `MOBILE_UA` en `YTMApp.kt` a un user agent de Chrome más reciente.
- No es una app oficial de Google. El audio sin anuncios y las descargas
  dependen de tener YouTube Music Premium en tu cuenta.
- Si el sistema ahorra batería de forma agresiva, desactiva la optimización
  de batería para claudeMusic.
