package app.ytmclient

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media.app.NotificationCompat.MediaStyle
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URL

/**
 * Servicio en primer plano: mantiene el proceso vivo mientras suena la música,
 * muestra la notificación con controles y expone una MediaSession
 * (pantalla de bloqueo, auriculares Bluetooth, etc.).
 * Los controles se ejecutan como JavaScript sobre YouTube Music.
 */
class PlaybackService : Service() {

    private lateinit var session: MediaSessionCompat
    private val handler = Handler(Looper.getMainLooper())

    private var title = ""
    private var artist = ""
    private var playing = false
    private var artUrl = ""
    private var art: Bitmap? = null

    private val webView get() = YTMApp.instance.webView

    private val poll = object : Runnable {
        override fun run() {
            queryState()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()

        session = MediaSessionCompat(this, "claudeMusic").apply {
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() = runJs(PLAY_JS)
                override fun onPause() = runJs(PAUSE_JS)
                override fun onSkipToNext() = runJs(NEXT_JS)
                override fun onSkipToPrevious() = runJs(PREV_JS)
            })
            isActive = true
        }

        startForegroundCompat()
        handler.post(poll)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY_PAUSE -> runJs(TOGGLE_JS)
            ACTION_NEXT -> runJs(NEXT_JS)
            ACTION_PREV -> runJs(PREV_JS)
            ACTION_STOP -> {
                runJs(PAUSE_JS)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        session.isActive = false
        session.release()
        super.onDestroy()
    }

    // ---------- Estado de reproducción ----------

    private fun queryState() {
        webView.evaluateJavascript(STATE_JS) { raw ->
            try {
                if (raw == null || raw == "null") return@evaluateJavascript
                val json = JSONObject(JSONTokener(raw).nextValue() as String)
                val newTitle = json.optString("t")
                val newArtist = json.optString("a")
                val newPlaying = json.optBoolean("p")
                val newArt = json.optString("img")

                val changed = newTitle != title || newArtist != artist ||
                    newPlaying != playing || newArt != artUrl
                title = newTitle
                artist = newArtist
                playing = newPlaying

                if (newArt != artUrl) {
                    artUrl = newArt
                    loadArt(newArt)
                }
                if (changed) publish()
            } catch (_: Exception) {
            }
        }
    }

    private fun loadArt(url: String) {
        if (url.isBlank()) {
            art = null
            return
        }
        Thread {
            try {
                val bmp = URL(url).openStream().use { BitmapFactory.decodeStream(it) }
                handler.post {
                    if (url == artUrl) {
                        art = bmp
                        publish()
                    }
                }
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun publish() {
        session.setMetadata(
            MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, artist)
                .putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, art)
                .build()
        )
        session.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(
                    PlaybackStateCompat.ACTION_PLAY or
                        PlaybackStateCompat.ACTION_PAUSE or
                        PlaybackStateCompat.ACTION_PLAY_PAUSE or
                        PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                        PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
                )
                .setState(
                    if (playing) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED,
                    PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN,
                    1f
                )
                .build()
        )
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    // ---------- Notificación ----------

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title.ifBlank { "claudeMusic" })
            .setContentText(artist)
            .setLargeIcon(art)
            .setContentIntent(openApp)
            .setOnlyAlertOnce(true)
            .setOngoing(playing)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(R.drawable.ic_prev, getString(R.string.prev), actionIntent(ACTION_PREV))
            .addAction(
                if (playing) R.drawable.ic_pause else R.drawable.ic_play,
                getString(if (playing) R.string.pause else R.string.play),
                actionIntent(ACTION_PLAY_PAUSE)
            )
            .addAction(R.drawable.ic_next, getString(R.string.next), actionIntent(ACTION_NEXT))
            .setStyle(
                MediaStyle()
                    .setMediaSession(session.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .build()
    }

    private fun actionIntent(action: String): PendingIntent =
        PendingIntent.getService(
            this, action.hashCode(),
            Intent(this, PlaybackService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
        )
    }

    private fun startForegroundCompat() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- Control de YouTube Music vía JS ----------

    private fun runJs(js: String) {
        handler.post {
            webView.evaluateJavascript(js, null)
            handler.postDelayed({ queryState() }, 400)
        }
    }

    companion object {
        private const val CHANNEL_ID = "playback"
        private const val NOTIF_ID = 1

        const val ACTION_PLAY_PAUSE = "app.ytmclient.PLAY_PAUSE"
        const val ACTION_NEXT = "app.ytmclient.NEXT"
        const val ACTION_PREV = "app.ytmclient.PREV"
        const val ACTION_STOP = "app.ytmclient.STOP"

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context, Intent(context, PlaybackService::class.java)
            )
        }

        private const val STATE_JS = """
            (function() {
              var m = navigator.mediaSession && navigator.mediaSession.metadata;
              var v = document.querySelector('video');
              var art = '';
              if (m && m.artwork && m.artwork.length) { art = m.artwork[m.artwork.length - 1].src; }
              return JSON.stringify({
                t: m ? m.title : '',
                a: m ? m.artist : '',
                p: v ? !v.paused : false,
                img: art
              });
            })();
        """

        private const val TOGGLE_JS = """
            (function() {
              var b = document.querySelector('ytmusic-player-bar #play-pause-button');
              if (b) { b.click(); return; }
              var v = document.querySelector('video');
              if (v) { v.paused ? v.play() : v.pause(); }
            })();
        """

        private const val PLAY_JS = """
            (function() {
              var v = document.querySelector('video');
              if (v && v.paused) {
                var b = document.querySelector('ytmusic-player-bar #play-pause-button');
                if (b) { b.click(); } else { v.play(); }
              }
            })();
        """

        private const val PAUSE_JS = """
            (function() {
              var v = document.querySelector('video');
              if (v && !v.paused) {
                var b = document.querySelector('ytmusic-player-bar #play-pause-button');
                if (b) { b.click(); } else { v.pause(); }
              }
            })();
        """

        private const val NEXT_JS = """
            (function() {
              var b = document.querySelector('ytmusic-player-bar .next-button');
              if (b) { b.click(); }
            })();
        """

        private const val PREV_JS = """
            (function() {
              var b = document.querySelector('ytmusic-player-bar .previous-button');
              if (b) { b.click(); }
            })();
        """
    }
}
