package app.ytmclient

import android.annotation.SuppressLint
import android.app.Application
import android.content.Intent
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * Mantiene el WebView vivo a nivel de aplicación, para que la música
 * siga sonando aunque la Activity se cierre o se envíe a segundo plano.
 */
class YTMApp : Application() {

    lateinit var webView: WebView
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        webView = createWebView()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val wv = WebView(this)
        wv.setBackgroundColor(0xFF000000.toInt())

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
            builtInZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            // User agent de Chrome móvil (sin "wv") para obtener la versión móvil completa
            userAgentString = MOBILE_UA
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val host = request.url.host ?: return false
                val internal = host.endsWith("youtube.com") ||
                    host.endsWith("google.com") ||
                    host.endsWith("gstatic.com") ||
                    host.endsWith("googleusercontent.com")
                if (internal) return false
                // Enlaces externos: abrir en el navegador del sistema
                try {
                    startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(request.url.toString()))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) {
                }
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                view.evaluateJavascript(KEEP_ALIVE_JS, null)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(KEEP_ALIVE_JS, null)
                CookieManager.getInstance().flush()
            }
        }

        wv.loadUrl(HOME_URL)
        return wv
    }

    companion object {
        const val HOME_URL = "https://music.youtube.com/"

        const val MOBILE_UA =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

        /**
         * Evita que YouTube Music detecte que la página está oculta
         * (lo que pausa la reproducción al irse a segundo plano).
         */
        const val KEEP_ALIVE_JS = """
            (function() {
              try {
                Object.defineProperty(document, 'hidden', { get: function() { return false; }, configurable: true });
                Object.defineProperty(document, 'visibilityState', { get: function() { return 'visible'; }, configurable: true });
                document.addEventListener('visibilitychange', function(e) { e.stopImmediatePropagation(); }, true);
                window.addEventListener('blur', function(e) { e.stopImmediatePropagation(); }, true);
              } catch (e) {}
            })();
        """

        lateinit var instance: YTMApp
            private set
    }
}
